document.addEventListener('DOMContentLoaded', () => {
  const dataEl = document.getElementById('categories-data');
  let CATEGORIES = {};
  try {
    CATEGORIES = dataEl ? JSON.parse(dataEl.textContent) : {};
  } catch (err) {
    console.error('Could not parse category data -- is this page being served by Flask (python app.py), not opened as a raw file?', err);
  }
  const categoryKeys = Object.keys(CATEGORIES);

  // Nicer display text for unit codes that aren't self-explanatory as-is.
  // Anything not listed here just displays as its raw code (e.g. "kg", "lb").
  const UNIT_LABELS = {
    ton: "metric ton", gal: "gal (US)", gal_uk: "gal (UK)", floz: "fl oz",
    barrel: "oil barrel", short_ton: "short ton (US)", long_ton: "long ton (UK)",
    troy_oz: "troy oz", acre_ft: "acre-ft", board_ft: "board ft", sqmile: "sq mile",
    mm2: "mm\u00B2", cm2: "cm\u00B2", m2: "m\u00B2", km2: "km\u00B2",
    ft2: "ft\u00B2", yd2: "yd\u00B2", kmh: "km/h", ms: "m/s",
    BTU_hr: "BTU/hr", ton_ref: "ton (refrigeration)",
  };
  const labelFor = (unit) => UNIT_LABELS[unit] || unit;

  const boxWrapper = document.getElementById('boxWrapper');
  const categorySelect = document.getElementById('categorySelect');
  const catIcon = document.getElementById('catIcon');
  const formulaNote = document.getElementById('formulaNote');
  const resetBtn = document.getElementById('resetBtn');

  let currentKey = categoryKeys[0];
  const debounceTimers = {};

  if (!currentKey) {
    formulaNote.textContent = 'No categories configured.';
    return;
  }

  categorySelect.innerHTML = categoryKeys
    .map((key) => `<option value="${key}">${CATEGORIES[key].label}</option>`)
    .join('');

  categoryKeys.forEach((key, i) => {
    const cat = CATEGORIES[key];
    const box = document.createElement('div');
    box.className = 'cat-box';
    box.dataset.key = key;
    if (i !== 0) box.style.display = 'none';

    const opts = cat.units.map((u) => `<option value="${u}">${labelFor(u)}</option>`).join('');
    box.innerHTML = `
      <div class="mode-toggle">
        <button class="modeBtn active" type="button" data-mode="one">One unit</button>
        <button class="modeBtn" type="button" data-mode="all">All units</button>
      </div>
      <div class="row">
        <input type="number" value="1" class="valInput" aria-label="Value to convert" />
        <select class="fromUnit" aria-label="From unit">${opts}</select>
      </div>
      <div class="one-mode">
        <div class="swap-row">
          <div class="swap-col">
            <button class="swapNumsBtn" type="button" aria-label="Swap numbers" title="Swap numbers">
              <i class="fa-solid fa-left-right" aria-hidden="true"></i>
            </button>
            <span>Values</span>
          </div>
          <div class="swap-col">
            <button class="swapUnitsBtn" type="button" aria-label="Swap units" title="Swap units">
              <i class="fa-solid fa-up-down" aria-hidden="true"></i>
            </button>
            <span>Units</span>
          </div>
        </div>
        <div class="row">
          <div class="resultOut">\u2014</div>
          <select class="toUnit" aria-label="To unit">${opts}</select>
        </div>
      </div>
      <div class="all-mode" style="display:none;">
        <div class="all-list"></div>
      </div>`;

    box.querySelector('.fromUnit').value = cat.default[0];
    box.querySelector('.toUnit').value = cat.default[1];
    boxWrapper.appendChild(box);

    const valInput = box.querySelector('.valInput');
    const fromSel = box.querySelector('.fromUnit');
    const toSel = box.querySelector('.toUnit');
    const oneModeEl = box.querySelector('.one-mode');
    const allModeEl = box.querySelector('.all-mode');
    const allListEl = box.querySelector('.all-list');
    let mode = 'one';

    valInput.addEventListener('input', () => {
      if (mode === 'one') {
        debounceConvert(box, key);
      } else {
        debounceConvertAll(box, key);
      }
    });

    fromSel.addEventListener('change', () => {
      if (mode === 'one') {
        convertBox(box, key);
        updateFormula(key, fromSel.value, toSel.value);
      } else {
        convertAllBox(box, key);
      }
    });

    toSel.addEventListener('change', () => {
      convertBox(box, key);
      updateFormula(key, fromSel.value, toSel.value);
    });

    box.querySelector('.swapUnitsBtn').addEventListener('click', () => {
      const tmp = fromSel.value;
      fromSel.value = toSel.value;
      toSel.value = tmp;
      convertBox(box, key);
      updateFormula(key, fromSel.value, toSel.value);
    });

    box.querySelector('.swapNumsBtn').addEventListener('click', () => {
      const resultOut = box.querySelector('.resultOut');
      const currentResult = parseFloat(resultOut.textContent.replace(/,/g, ''));
      if (Number.isNaN(currentResult)) return;
      valInput.value = currentResult;
      convertBox(box, key);
    });

    box.querySelectorAll('.modeBtn').forEach((btn) => {
      btn.addEventListener('click', () => {
        mode = btn.dataset.mode;
        box.querySelectorAll('.modeBtn').forEach((b) => b.classList.toggle('active', b === btn));
        if (mode === 'one') {
          oneModeEl.style.display = '';
          allModeEl.style.display = 'none';
          formulaNote.style.display = '';
          convertBox(box, key);
          updateFormula(key, fromSel.value, toSel.value);
        } else {
          oneModeEl.style.display = 'none';
          allModeEl.style.display = '';
          formulaNote.style.display = 'none';
          convertAllBox(box, key);
        }
      });
    });

    async function convertAllBox(boxEl, categoryKey) {
      const value = valInput.value;
      if (value === '' || Number.isNaN(parseFloat(value))) {
        allListEl.innerHTML = '<p class="all-list-error">Enter a value</p>';
        return;
      }
      try {
        const response = await fetch('/api/convert-all', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ category: categoryKey, from_unit: fromSel.value, value }),
        });
        const data = await response.json();
        if (data.error) {
          allListEl.innerHTML = `<p class="all-list-error">${data.error}</p>`;
          return;
        }
        allListEl.innerHTML = data.results.map((row) => `
          <button class="all-row ${row.unit === fromSel.value ? 'active' : ''}" data-unit="${row.unit}" data-value="${row.result}" type="button">
            <span>${labelFor(row.unit)}</span>
            <strong>${Number(row.result).toLocaleString(undefined, { maximumFractionDigits: 4 })}</strong>
          </button>`).join('');
        allListEl.querySelectorAll('.all-row').forEach((rowBtn) => {
          rowBtn.addEventListener('click', () => {
            valInput.value = rowBtn.dataset.value;
            fromSel.value = rowBtn.dataset.unit;
            convertAllBox(boxEl, categoryKey);
          });
        });
      } catch (err) {
        allListEl.innerHTML = '<p class="all-list-error">Connection error</p>';
      }
    }

    const debounceConvertAll = (boxEl, categoryKey) => {
      clearTimeout(debounceTimers[categoryKey + '-all']);
      debounceTimers[categoryKey + '-all'] = setTimeout(() => convertAllBox(boxEl, categoryKey), 200);
    };

    box._convertAllBox = convertAllBox;
    box._getMode = () => mode;
  });

  function debounceConvert(box, key) {
    clearTimeout(debounceTimers[key]);
    debounceTimers[key] = setTimeout(() => convertBox(box, key), 200);
  }

  async function convertBox(box, key) {
    const valInput = box.querySelector('.valInput');
    const fromUnit = box.querySelector('.fromUnit').value;
    const toUnit = box.querySelector('.toUnit').value;
    const resultOut = box.querySelector('.resultOut');
    const rawValue = valInput.value;

    if (rawValue === '' || Number.isNaN(parseFloat(rawValue))) {
      resultOut.textContent = 'Enter a value';
      resultOut.classList.add('error');
      return;
    }

    try {
      const response = await fetch('/api/convert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ category: key, from_unit: fromUnit, to_unit: toUnit, value: rawValue }),
      });
      const data = await response.json();

      if (data.error) {
        resultOut.textContent = data.error;
        resultOut.classList.add('error');
        return;
      }

      resultOut.classList.remove('error');
      resultOut.textContent = Number(data.result).toLocaleString(undefined, { maximumFractionDigits: 4 });
    } catch (err) {
      resultOut.textContent = 'Connection error';
      resultOut.classList.add('error');
    }
  }

  async function updateFormula(key, fromUnit, toUnit) {
    if (key === 'temperature') {
      formulaNote.textContent = 'Temperature uses an offset formula, not a fixed multiplier.';
      return;
    }
    try {
      const response = await fetch('/api/convert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ category: key, from_unit: fromUnit, to_unit: toUnit, value: 1 }),
      });
      const data = await response.json();
      if (data.error) {
        formulaNote.textContent = '';
        return;
      }
      const ratio = Number(data.result).toLocaleString(undefined, { maximumFractionDigits: 6 });
      formulaNote.textContent = `1 ${labelFor(fromUnit)} = ${ratio} ${labelFor(toUnit)}`;
    } catch (err) {
      formulaNote.textContent = '';
    }
  }

  function switchCategory(key) {
    const oldBox = document.querySelector(`.cat-box[data-key="${currentKey}"]`);
    const newBox = document.querySelector(`.cat-box[data-key="${key}"]`);
    if (!oldBox || !newBox) return;

    oldBox.classList.add('fade-out');
    setTimeout(() => {
      oldBox.style.display = 'none';
      oldBox.classList.remove('fade-out');
      currentKey = key;
      catIcon.className = `fa-solid fa-${CATEGORIES[key].icon}`;
      newBox.style.display = '';
      newBox.classList.add('fade-in');

      const fromSel = newBox.querySelector('.fromUnit');
      const toSel = newBox.querySelector('.toUnit');
      if (newBox._getMode && newBox._getMode() === 'all') {
        newBox._convertAllBox(newBox, key);
      } else {
        convertBox(newBox, key);
        updateFormula(key, fromSel.value, toSel.value);
      }

      requestAnimationFrame(() => {
        requestAnimationFrame(() => newBox.classList.remove('fade-in'));
      });
    }, 150);
  }

  categorySelect.addEventListener('change', (e) => switchCategory(e.target.value));

  resetBtn.addEventListener('click', () => {
    const box = document.querySelector(`.cat-box[data-key="${currentKey}"]`);
    const cat = CATEGORIES[currentKey];
    box.querySelector('.valInput').value = 1;
    box.querySelector('.fromUnit').value = cat.default[0];
    box.querySelector('.toUnit').value = cat.default[1];
    if (box._getMode && box._getMode() === 'all') {
      box._convertAllBox(box, currentKey);
    } else {
      convertBox(box, currentKey);
      updateFormula(currentKey, cat.default[0], cat.default[1]);
    }
  });

  // Initial render
  catIcon.className = `fa-solid fa-${CATEGORIES[currentKey].icon}`;
  const firstBox = document.querySelector(`.cat-box[data-key="${currentKey}"]`);
  convertBox(firstBox, currentKey);
  updateFormula(currentKey, CATEGORIES[currentKey].default[0], CATEGORIES[currentKey].default[1]);
});